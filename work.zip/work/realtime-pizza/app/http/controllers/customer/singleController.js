const Order = require('../../../models/order')
const moment = require('moment')

exports.single = async (req, res) => {
    const order = await Order.findById(req.params.id).select('customerId status updatedAt').exec()
    res.render('customer/single', { order: order, moment: moment })
}