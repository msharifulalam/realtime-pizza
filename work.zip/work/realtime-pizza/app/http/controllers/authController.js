const bcrypt = require('bcrypt')
const User = require('../../models/user')
const passport = require('passport')

exports.login = (req, res) => {
    res.render('auth/login')
}

// exports.postLogin = (req, res, next) => {
//     passport.authenticate('local', (error, user, info) => {
//         if(error){
//             req.flash('error', info.message)
//             return next()
//         }

//         if(!user){
//             req.flash('error', info.message)
//             res.redirect('/login')
//         }

//         req.logIn(user, (error) => {
//             if(error){
//                 req.flash('error', info.message)
//                 return next()
//             }
//             return res.redirect('/')
//         })
//     })(req, res, next)
// }

exports.postLogin = (req, res, next) => {
    passport.authenticate('local', {
        successRedirect: '/',
        failureRedirect: '/login',
        failureFlash: true
    })(req, res, next)
}

exports.getLogout = (req, res) => {
    // if(req.session.passport) return res.render('notfound')
    if(req.user) return res.render('notfound')
    return res.redirect('/login')
}

exports.postLogout = (req, res) => {
    req.logOut()
    // if(req.session.passport) req.session.passport = null
    res.redirect('/login')
}

exports.register = (req, res) => {
    res.render('auth/register')
}

exports.postRegister = async (req, res) => {
    const { username, useremail, userpassword } = req.body

    if(!username || !useremail || !userpassword){
        req.flash('error', 'All fields are required!')
        req.flash('name', username)
        req.flash('email', useremail)
        req.flash('password', userpassword)
        return res.redirect('/register')
    }
    // console.log(await User.exists({ email: useremail }))
    // await User.exists({ email: useremail }, (error, res) => {
    //     console.log(error)
    //     console.log(res)
    // })

    // check email exists
    if(await User.exists({ email: useremail })){
        req.flash('exists', 'Email already exists')
        req.flash('name', username)
        req.flash('email', useremail)
        req.flash('password', userpassword)
        return res.redirect('/register')
    }

    //hash password
    let hashedPassword = await bcrypt.hash(userpassword, 10)

    let user = new User({
        name: username,
        email: useremail,
        password: hashedPassword
    })

    try {
        await user.save()
        res.status(202).redirect('/login')
    } catch (error) {
        console.log('error: something wrong!')
    }
}
