const Order = require('../../../models/order')
const moment = require('moment')


exports.pk = async (req, res) => {
    let localVersion = 0
    

    const orders = await Order.find({ 
        status: { $ne: 'completed' } }, 
        null, 
        { sort: { createdAt: -1 } }
    ).populate('customerId', '-password').exec()
    try {
        res.setHeader('Content-Type', 'text/event-stream')
        res.setHeader('Connection', 'keep-alive')
        res.setHeader('Cache-Control', 'no-cache')
        res.setHeader('Access-Control-Allow-Origin', '*')
        
        res.write(`data: ${JSON.stringify(orders)}\n\n`)
    } catch (error) {
        console.log(error)
    }
}

exports.index = async (req, res) => {
    await Order.find({ 
        status: { $ne: 'completed' } }, 
        null, 
        { sort: { createdAt: -1 } }
    ).populate('customerId', '-password').exec((error, orders) => {
        if(req.xhr){
            return res.json(orders)
        }
        return res.render('admin/orders', { orders: orders, moment: moment })
        // console.log(orders)
    })
}

exports.status = async (req, res) => {
    const { orderId, status } = req.body
    if(orderId && status){
        await Order.updateOne( { _id: orderId }, { status: status }, (err, data) => {
            if(err){
                return res.redirect('/admin/orders')
            }
            return res.redirect('/admin/orders')
        })
    }
}