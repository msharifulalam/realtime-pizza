import axios from 'axios';
import Noty from 'noty';
import moment from "moment";
import { initAdmin, initAdminSSE, updateStatus } from './admin'

console.log('Hello from client side js');

let addToCart = document.querySelectorAll('.add-to-cart');
let cartCounter = document.querySelector('#cart-counter');

function updateCart(pizza){
    axios.post('/update-cart', pizza).then(res => {
        // console.log(cartCounter.innerHTML)
        cartCounter.innerText = res.data.quantity;
        new Noty({
            type: 'success',
            text: 'Item added to cart',
            layout: 'bottomRight',
            timeout: 1000,
            progressBar: false
        }).show();
    }).catch(err => {
        new Noty({
            type: 'error',
            text: 'Something went wrong!',
            timeout: 1000,
            progressBar: false
        }).show();
    })
}


addToCart.forEach((btn) => {
    btn.addEventListener('click', (e) => {
        let pizza = JSON.parse(btn.dataset.pizza);
        updateCart(pizza);
    })
})

const successAlert = document.querySelector('#success-alert');
if(successAlert){
    setTimeout(() => {
        successAlert.remove();
    }, 2000)
}

// Admin JS
// initAdmin()
initAdminSSE()
// updateStatus()


// Status area
let statusList = document.querySelectorAll('.stage-status'),
    inputOrder = document.querySelector('#hiddenOrder');
let hiddenOrder = inputOrder ? inputOrder.value : null,
    stepCompleted = true,
    span = document.createElement('span');
    span.setAttribute('class', 'fl-r');

hiddenOrder = JSON.parse(hiddenOrder);

statusList.forEach(state => {
    let status = state.dataset.status;
    if(stepCompleted){
        state.classList.add('completed');
        span.innerText = moment(hiddenOrder.updatedAt).format('hh:mm A');
        state.appendChild(span);
    }
    if(hiddenOrder.status === status){
        stepCompleted = false;
        if(state.nextElementSibling){
            state.nextElementSibling.classList.add('current');
        }
    }

})