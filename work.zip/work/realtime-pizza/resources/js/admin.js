import axios from "axios";
import moment from "moment";

export function initAdminSSE(){
    
    let orderTableBody = document.querySelector('#orderTableBody');
    let orders = [];
    let markup;
    var eventSourceInitDict = { https: { rejectUnauthorized: false } };
    const eventSource = new EventSource('/stream', eventSourceInitDict);
    eventSource.addEventListener('message', e => {
        orders = JSON.parse(e.data);
        markup = generateMarkup(orders);
        if(orderTableBody){
            orderTableBody.innerHTML = markup;
        }
    });
    function renderItems(items){
        let parsedItems = Object.values(items);
        return parsedItems.map(menuItem => {
            return `
                <p>${ menuItem.item.name } - ${ menuItem.qty } pcs </p>
            `;
        }).join('');
    }

    // markup
    function generateMarkup(orders){
        return orders.map(order => {
            return `
                    <tr>
                    <td class="border px-4 py-2 text-green-900">
                        <p>${ order._id }</p>
                        <div>${ renderItems(order.items) }</div>
                    </td>
                    <!-- <td class="border px-4 py-2">
                        <a href="#" class="link"></a>
                    </td> -->
                    <td class="border px-4 py-2">${ order.customerId.name }</td>
                    <td class="border px-4 py-2">${ order.address }</td>
                    <td class="border px-4 py-2">
                        <div class="inline-block relative w-64">
                            <form id="status_form" action="/admin/order/status" method="POST">
                                <input type="hidden" name="orderId" value="${ order._id }">
                                <select name="status" onchange="this.form.submit()" class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline">
                                    <option value="order_placed" ${ (order.status === 'order_placed') ? 'selected' : '' }>
                                        Placed
                                    </option>
                                    <option value="confirmed" ${ (order.status === 'confirmed') ? 'selected' : '' }>
                                        confirmed
                                    </option>
                                    <option value="prepared" ${ (order.status === 'prepared') ? 'selected' : '' }>
                                        prepared
                                    </option>
                                    <option value="delivered" ${ (order.status === 'delivered') ? 'selected' : '' }>
                                        delivered
                                    </option>
                                    <option value="completed" ${ (order.status === 'completed') ? 'selected' : '' }>
                                        completed
                                    </option>
                                </select>
                            </form>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                    </td>
                    <td class="border px-4 py-2">
                        ${ moment(order.createdAt).format('hh:mm A') }
                    </td>
                    </tr>
            `
        }).join('');
    }
}

export function initAdmin(){
    let orderTableBody = document.querySelector('#orderTableBody');

    let orders = [];
    let markup;

    axios.get('/admin/orders', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    }).then((res) => {
        orders = res.data;
        console.log(JSON.stringify(orders));
        markup = generateMarkup(orders);
        if(orderTableBody){
            orderTableBody.innerHTML = markup;
        }
    }).catch(error => {
        console.log(error);
    });

    function renderItems(items){
        let parsedItems = Object.values(items)
        return parsedItems.map(menuItem => {
            return `
                <p>${ menuItem.item.name } - ${ menuItem.qty } pcs </p>
            `;
        }).join('');
    }

    // markup
    function generateMarkup(orders){
        return orders.map(order => {
            return `
                    <tr>
                    <td class="border px-4 py-2 text-green-900">
                        <p>${ order._id }</p>
                        <div>${ renderItems(order.items) }</div>
                    </td>
                    <!-- <td class="border px-4 py-2">
                        <a href="#" class="link"></a>
                    </td> -->
                    <td class="border px-4 py-2">${ order.customerId.name }</td>
                    <td class="border px-4 py-2">${ order.address }</td>
                    <td class="border px-4 py-2">
                        <div class="inline-block relative w-64">
                            <form id="status_form" action="/admin/order/status" method="POST">
                                <input type="hidden" name="orderId" value="${ order._id }">
                                <select name="status" onchange="this.form.submit()" class="block appearance-none w-full bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline">
                                    <option value="order_placed" ${ (order.status === 'placed') ? 'selected' : '' }>
                                        Placed
                                    </option>
                                    <option value="confirmed" ${ (order.status === 'confirmed') ? 'selected' : '' }>
                                        confirmed
                                    </option>
                                    <option value="prepared" ${ (order.status === 'prepared') ? 'selected' : '' }>
                                        prepared
                                    </option>
                                    <option value="delivered" ${ (order.status === 'delivered') ? 'selected' : '' }>
                                        delivered
                                    </option>
                                    <option value="completed" ${ (order.status === 'completed') ? 'selected' : '' }>
                                        completed
                                    </option>
                                </select>
                            </form>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                    </td>
                    <td class="border px-4 py-2">
                        ${ moment(order.createdAt).format('hh:mm A') }
                    </td>
                    </tr>
            `
        }).join('');
    }

}

export function updateStatus(){
    let statusForm = document.querySelector('#status_form');
    // axios.post('/admin/order/status', { data: new FormData(statusForm)}).then(res => {
    //     console.log(res.data);
    // }).catch(err => console.log(err));
    if(statusForm){
        statusForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // axios.post('/admin/order/status', { 
            // userId: ,
            // status: 
            // }).then(res => {
            //         console.log(res.data);
            // }).catch(err => console.log(err));
            console.log(e);
        })
    }
}