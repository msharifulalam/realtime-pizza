const express = require('express')
const router = express.Router()
// const SSE = require('express-sse')
// const sse = new SSE()

const homeController = require('../app/http/controllers/homeController')
const authController = require('../app/http/controllers/authController')
const cartController = require('../app/http/controllers/customer/cartController')
const orderController = require('../app/http/controllers/customer/orderController')
const guestMiddleware = require('../app/http/middleware/guest')
const adminOrderController = require('../app/http/controllers/admin/orderController')
const singleController = require('../app/http/controllers/customer/singleController')
/****************************** Home Controller ******************************/
router.get('/', homeController.index)
/****************************** Home Controller ******************************/


/****************************** Cart Controller ******************************/
router.post('/update-cart', cartController.update)

router.get('/cart', guestMiddleware.checkAuthenticated, cartController.cart)
/****************************** Cart Controller ******************************/


/****************************** Auth Controller ******************************/
router.get('/register', guestMiddleware.checkNotAuthenticated, authController.register)

router.post('/register', guestMiddleware.checkNotAuthenticated, authController.postRegister)

router.get('/login', guestMiddleware.checkNotAuthenticated, authController.login)

router.post('/login', guestMiddleware.checkNotAuthenticated, authController.postLogin)

router.get('/logout', authController.getLogout)

router.delete('/logout', authController.postLogout)
/****************************** Auth Controller ******************************/


/****************************** Order Controller ******************************/
// Customer routes
router.post('/orders', guestMiddleware.checkAuthenticated, orderController.order)

router.get('/customer/orders', guestMiddleware.checkAuthenticated, orderController.index)

router.get('/customer/orders/:id', singleController.single)

// Admin routes
router.get('/admin/orders', adminOrderController.index)

router.get('/stream', adminOrderController.pk)
// router.get('/admin/orders/pk', sse.init, adminOrderController.pk)

// Status update
router.post('/admin/order/status', adminOrderController.status)

/****************************** Order Controller ******************************/



// router.get('/register', (req, res) => { 
//     res.render('auth/register') 
// })



module.exports = router