if(process.env.NODE_ENV !== 'production') require('dotenv').config()

const express = require('express')
const app = express()
const mongoose = require('mongoose')
const ejs = require('ejs')
const expressLayout = require('express-ejs-layouts')
const path = require('path')
// Socket
const socket = require('socket.io')
// SSE
const sse = require('sse')
//method override
const methodOverride = require('method-override')
// passport auth
const passport = require('passport');
const initializePassport = require('./app/config/passport/passport-config')

// port
const port = process.env.PORT || 4500

// initialize passport
initializePassport.init(passport)


/********* SESSION SETUP **********/
// express-session
const session = require('express-session')
// cookie-parser
// const cookie = require('cookie-parser')
//express flash
const flash = require('express-flash')
const MongoDBStore = require('connect-mongo')(session)
/********* SESSION SETUP **********/

// routing files
const webRoutes = require('./routes/web')
//mongoose default connection
const DB = process.env.DATABASE
mongoose.connect(DB, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true })
const mongoose_connection = mongoose.connection
//connection check
// mongoose_connection.on('error', console.error.bind(console, 'MongoDB connection error!'))
mongoose_connection.once(
    'open', () => console.log('connected to the database')
).catch(
    error => console.log('MongoDB connection error!')
)

/********* SESSION STORE **********/
const mongoStore = new MongoDBStore({
    mongooseConnection: mongoose_connection,
    collection: 'pizza-sessions'
})
/********* SESSION STORE **********/
/********* SESSION CONFIG MIDDLEWARE **********/
// session config
app.use(session({
    secret: process.env.SECRET_KEY,
    resave: false,
    store: mongoStore,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24
    }
}))
app.use(flash())



global.globalVersion = 0
// app.use()
/********* SESSION CONFIG MIDDLEWARE **********/

// set template engine
app.use(express.json())
app.use(expressLayout)
app.use(express.static('public'))

app.set('views', path.join(__dirname, '/resources/views'))
app.set('view engine', 'ejs')

// url
app.use(express.urlencoded({ extended: false }))

// passport configuration 
app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) => {
    res.locals.session = req.session
    res.locals.user = req.user
    next()
})

//method override
app.use(methodOverride('_method'))
// Router setup
app.use('', webRoutes)
app.use(sse)

const server = app.listen(port, () => console.log('Listening on port ', port))
//server for future use
const io = socket(server)
io.on('connection', () => {
    //join
    
})