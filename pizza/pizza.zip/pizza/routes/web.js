const express = require('express')
const router = express.Router()
const homeController = require('../app/http/controllers/homeController')
const authController = require('../app/http/controllers/authController')
const cartController = require('../app/http/controllers/customers/cartController')

router.get('/', homeController.index)

router.get('/cart', cartController.cart)

router.get('/register', authController.register)

router.get('/login', authController.login)

router.post('/update-cart', cartController.update)

// router.get('/register', (req, res) => { 
//     res.render('auth/register') 
// })

module.exports = router