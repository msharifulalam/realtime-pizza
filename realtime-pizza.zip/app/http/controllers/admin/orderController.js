const Order = require('../../../models/order')
const moment = require('moment')


exports.index = async (req, res) => {
    await Order.find({ 
        status: { $ne: 'completed' } }, 
        null, 
        { sort: { createdAt: -1 } }
    ).populate('customerId', '-password').exec((error, orders) => {
        if(req.xhr){
            return res.json(orders)
        }
        return res.render('admin/orders', { orders: orders, moment: moment })
        // console.log(orders)
    })
}