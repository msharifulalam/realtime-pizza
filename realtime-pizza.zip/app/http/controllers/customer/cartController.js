exports.cart = (req, res) => {
    res.render('customer/cart')
    // res.render('customers/cart', { pizzaCart: req.session.cart })
}

exports.update = (req, res) => {
    // cart structure
    // cart = {
    //     items: {
    //         pizzaId(1): { item: pizzaObject, qty: 2 },
    //         pizzaId(2): { item: pizzaObject, qty: 1 }
    //     },
    //     totalQty: 0,
    //     totalPrice: 0
    // }

    if(!req.session.cart){
        req.session.cart = {
            items: {},
            totalQty: 0,
            totalPrice: 0
        }
    }
    
    let cart = req.session.cart
    if(!cart.items[req.body.id]){
        cart.items[req.body.id] = {
            item: req.body,
            qty: 1
        }
        cart.totalQty = cart.totalQty + 1
        cart.totalPrice = cart.totalPrice + req.body.price
    }else{
        let itemId = cart.items[req.body.id]
        itemId.qty = itemId.qty + 1
        cart.totalQty = cart.totalQty + 1
        cart.totalPrice = cart.totalPrice + req.body.price
    }
    
    res.json({ quantity: cart.totalQty })
}
