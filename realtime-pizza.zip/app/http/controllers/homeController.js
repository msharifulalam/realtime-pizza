const mongoose = require('mongoose')
const Menu = require('../../models/menu')

exports.index = async (req, res) => {
    const dMenus = await Menu.find()
    
    const menus = [{
        id: 1,
        name: 'Mergherita',
        image: "/img/pizza.png",
        price: 200,
        size: 'Medium',
        description: 'Delicious Mergherita',
        createdAt: Date.now()
    },
    {
        id: 2,
        name: 'Dominos',
        image: "/img/pizza.png",
        price: 100,
        size: 'Small',
        description: 'Delicious Dominos',
        createdAt: Date.now()
    },
    {
        id: 3,
        name: 'Mergherita',
        image: "/img/pizza.png",
        price: 100,
        size: 'small',
        description: 'Delicious Mergherita',
        createdAt: Date.now()
    },
    {
        id: 4,
        name: 'Dominos',
        image: "/img/pizza.png",
        price: 400,
        size: 'large',
        description: 'Delicious Dominos',
        createdAt: Date.now()
    },
    {
        id: 5,
        name: 'Pepperoni',
        image: "/img/pizza.png",
        price: 200,
        size: 'Medium',
        description: 'Delicious Pepperoni',
        createdAt: Date.now()
    },
    {
        id: 6,
        name: 'Panner',
        image: "/img/pizza.png",
        price: 100,
        size: 'Small',
        description: 'Delicious Panner',
        createdAt: Date.now()
    }]

    if(dMenus){
        return res.render('home', { menus: menus })
    }else{
        return res.render('home', { menus: dMenus })
    }
    
}

// factory function: Object creational pattern will return an object

// function homeController(){
//     // 
    
//     return {
//         index(req, res) {
//              res.render('home')
        // }
//     }
// }