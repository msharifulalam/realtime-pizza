const { authenticate } = require('passport')
const User = require('../../models/user')
const bcrypt = require('bcrypt')
const LocalStrategy = require('passport-local').Strategy

function init(passport){
    const authenticateUser = (email, password, done) => {
        //find user with the email
        User.findOne({ email: email }, async (error, user) => {

            if(error) return done(error)
            if(!user) return done(null, false, { message: 'Incorrect email or password.' })
            try {
                let pass = await bcrypt.compare(password, user.password)
                if(!pass){
                    return done(null, false, { message: 'Incorrect password.' })
                }
                return done(null, user)
            } catch (error) {
                return done(error)
            }
            
        })
    }
    passport.use(new LocalStrategy(
        {
            usernameField: 'email',
            passwordField: 'password'
        },
        authenticateUser
    ))
    passport.serializeUser((user, done) => {
        done(null, user.id)
    })
    passport.deserializeUser((id, done) => {
        User.findById(id, (error, user) => {
            done(error, user)
        })
    })
}

module.exports = {
    init
}