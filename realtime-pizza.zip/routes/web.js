const express = require('express')
const router = express.Router()
const homeController = require('../app/http/controllers/homeController')
const authController = require('../app/http/controllers/authController')
const cartController = require('../app/http/controllers/customer/cartController')
const orderController = require('../app/http/controllers/customer/orderController')
const guestMiddleware = require('../app/http/middleware/guest')
const adminOrderController = require('../app/http/controllers/admin/orderController')

router.get('/', homeController.index)

router.get('/cart', guestMiddleware.checkAuthenticated, cartController.cart)

router.get('/register', guestMiddleware.checkNotAuthenticated, authController.register)

router.post('/register', guestMiddleware.checkNotAuthenticated, authController.registerANewUser)

router.get('/login', guestMiddleware.checkNotAuthenticated, authController.login)

router.post('/login', guestMiddleware.checkNotAuthenticated, authController.postLogin)

router.get('/logout', authController.getLogout)

router.delete('/logout', authController.postLogout)

router.post('/update-cart', cartController.update)

// Customer routes
router.post('/orders', guestMiddleware.checkAuthenticated, orderController.order)

router.get('/customer/orders', guestMiddleware.checkAuthenticated, orderController.index)

// Admin routes
router.get('/admin/orders', adminOrderController.index)

// router.get('/register', (req, res) => { 
//     res.render('auth/register') 
// })



module.exports = router